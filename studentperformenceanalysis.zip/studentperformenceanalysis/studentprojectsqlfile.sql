create database project_student;
use project_student;

select * from cleaned_student_performance;

--  Count total students.  
SELECT COUNT(*) AS total_students
FROM cleaned_student_performance;
--  Calculate average marks.  
SELECT AVG(percentage) AS average_marks
FROM cleaned_student_performance;
--  Find top 10 performing students.  
SELECT student_id, student_name, total_marks, percentage
FROM cleaned_student_performance
ORDER BY total_marks DESC
LIMIT 10;
--  Analyze gender-wise performance.  
SELECT
    gender,
    COUNT(*) AS total_students,
    AVG(percentage) AS average_percentage,
    AVG(total_marks) AS average_total_marks
FROM cleaned_student_performance
GROUP BY gender;
--  Calculate average attendance.  
SELECT AVG(attendance_percentage) AS average_attendance
FROM cleaned_student_performance;
--  Find students scoring above 90%.
SELECT student_id, student_name, percentage
FROM cleaned_student_performance
WHERE percentage > 90
ORDER BY percentage DESC;  
--  Analyze performance by parental education. 
SELECT
    parental_education,
    COUNT(*) AS total_students,
    AVG(percentage) AS average_percentage
FROM cleaned_student_performance
GROUP BY parental_education
ORDER BY average_percentage DESC; 
--  Rank students based on total marks.  
SELECT
    student_id,
    student_name,
    total_marks,
    RANK() OVER (ORDER BY total_marks DESC) AS student_rank
FROM cleaned_student_performance;
--  Find average study hours.  
SELECT AVG(study_hours_per_day) AS average_study_hours
FROM cleaned_student_performance;
--  Identify pass and fail percentages.  
SELECT
    result,
    COUNT(*) AS total_students,
    ROUND(
        COUNT(*) * 100.0 / (SELECT COUNT(*) FROM cleaned_student_performance),
        2
    ) AS percentage
FROM cleaned_student_performance
GROUP BY result;